import React from 'react';
import { LineChart, Users, Bell } from 'lucide-react';

const features = [
  {
    icon: <LineChart className="h-10 w-10 text-purple-400" />,
    title: "Expert Analysis",
    description: "Institutional-grade research and trade strategies."
  },
  {
    icon: <Users className="h-10 w-10 text-purple-400" />,
    title: "Community Power",
    description: "Active chat rooms & live support."
  },
  {
    icon: <Bell className="h-10 w-10 text-purple-400" />,
    title: "Real-Time Alerts",
    description: "Instant buy/sell signals."
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-16 px-12">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-[42px] uppercase tracking-[4px] text-purple-400 mb-12 text-center">
          A Glimpse of What We Offer
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group feature-card !p-12 hover:border-purple-500/30 transition-all duration-500"
            >
              <div className="mb-8 transform group-hover:scale-110 transition-transform duration-500">
                {feature.icon}
              </div>
              
              <h3 className="text-[20px] font-light tracking-[2px] mb-4">
                {feature.title}
              </h3>
              
              <p className="text-[14px] text-white/60">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;