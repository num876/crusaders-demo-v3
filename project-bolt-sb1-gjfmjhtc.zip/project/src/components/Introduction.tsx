import React from 'react';

const Introduction: React.FC = () => {
  return (
    <section className="pt-32 md:pt-48 px-4 md:px-12">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-[28px] md:text-[42px] uppercase tracking-[4px] text-purple-400 mb-8 md:mb-12 text-center">
          What Is Crypto Crusaders?
        </h2>
        
        <div className="max-w-[800px] mx-auto text-[16px] md:text-[18px] leading-relaxed space-y-6 md:space-y-8 text-white/80">
          <p className="text-center md:text-left">
            Crypto Crusaders is a community that works for you to potentially hit upwards of 20-100x gain on your investment for this upcoming crypto Bull Run.
          </p>
          
          <p className="text-center md:text-left">
            It allows you to make profits your average normie couldn't fathom without prior crypto knowledge, gambling on risky trades, or staring at charts all day long.
          </p>
          
          <p className="text-center md:text-left">
            Inside, you will get access to the 20-100X coins we're invested in, instantly. You'll also get access to our research sheets, why we're even bullish on these projects, and in-depth updates of what's happening regarding the Macro market - calling each market pump and pullback in advance to perfection.
          </p>
          
          <p className="text-center md:text-left">
            This means you can simply spend a few minutes per day reading through any occasional updates we may send you so you know your money is invested in actual, backed projects that are day-by-day, getting bigger & bigger.
          </p>
          
          <p className="text-center md:text-left">
            So you can potentially make upwards of 6, 7, or even 8 figures even if you feel "stuck" in your office job, are a busy student, or all of your time is being funneled into your business already.
          </p>
          
          <p className="text-center md:text-left">
            Thus, you can hit upwards of 20-100x total on your portfolio in the next few months while doing little to none of the work. It's that simple. Welcome to CC.
          </p>
        </div>
        
        <div className="w-full h-px bg-gradient-to-r from-transparent via-purple-500/30 to-transparent my-16 md:my-24" />
        
        <div className="max-w-[800px] mx-auto px-4 md:px-0">
          <h4 className="text-[20px] md:text-[24px] font-medium text-purple-400 mb-8 text-center md:text-left">Here's How Crypto Crusaders Helps You</h4>
            
          <div className="space-y-8">
            <div className="text-center md:text-left">
              <h5 className="text-[16px] md:text-[18px] font-medium mb-2">Plug-and-Play Coin Picks</h5>
              <p>We share our top 20–100× coin ideas. You just follow along—no chart reading required.</p>
            </div>
              
            <div className="text-center md:text-left">
              <h5 className="text-[16px] md:text-[18px] font-medium mb-2">Simple, Clear Updates</h5>
              <p>Get straightforward messages: "Buy X," "Sell Y." Plus quick reports on the overall market.</p>
            </div>
              
            <div className="text-center md:text-left">
              <h5 className="text-[16px] md:text-[18px] font-medium mb-2">Minutes Per Day</h5>
              <p>Spend as little as five minutes checking our alerts—then go about your life.</p>
            </div>
          </div>
            
          <h4 className="text-[20px] md:text-[24px] font-medium text-purple-400 mt-16 mb-8 text-center md:text-left">Why Trust Us?</h4>
            
          <div className="space-y-4 text-center md:text-left">
            <p><span className="font-medium">Expert Team:</span> I pay top analysts to do the heavy lifting so you don't have to guess.</p>
            <p><span className="font-medium">Real Results:</span> In the last slow market, our 350 members made over $2 million together.</p>
          </div>
            
          <h4 className="text-[20px] md:text-[24px] font-medium text-purple-400 mt-16 mb-8 text-center md:text-left">Who This Is For</h4>
            
          <div className="space-y-4 text-center md:text-left">
            <p><span className="font-medium">You:</span> If you only invest money you can afford to lose, and you want a shot at big returns.</p>
            <p><span className="font-medium">Not You:</span> If you're looking for "get rich quick" schemes or gambling with loans—this isn't it.</p>
          </div>
            
          <h4 className="text-[20px] md:text-[24px] font-medium text-purple-400 mt-16 mb-8 text-center md:text-left">My Guarantee</h4>
            
          <p className="text-center md:text-left">
            If you aren't in profit after 90 days, I will refund 100% of your entry fee—no questions asked.*
          </p>
            
          <h4 className="text-[20px] md:text-[24px] font-medium text-purple-400 mt-16 mb-8 text-center md:text-left">Ready to Jump In?</h4>
            
          <p className="text-center md:text-left">
            Spots fill up fast. If you want real, research-backed crypto gains without the guesswork, apply now and join Crypto Crusaders.
          </p>
            
          <p className="mt-8 text-center md:text-left">
            Welcome aboard—you're in good company.
          </p>
            
          <p className="mt-16 text-[12px] md:text-[14px] text-white/60 italic text-center md:text-left">
            *Simple verification of your trades required. See our guarantee policy for details.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Introduction;