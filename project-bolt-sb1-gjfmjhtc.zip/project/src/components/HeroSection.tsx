import React from 'react';
import { ArrowRight } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 md:px-8 pt-24 md:pt-32">
      {/* Rotating ring accent */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[600px] h-[300px] md:h-[600px] pointer-events-none">
        <div className="absolute inset-0 border-2 border-purple-500/20 rounded-full animate-[spin_20s_linear_infinite]" />
        <div className="absolute inset-0 border-2 border-purple-500/10 rounded-full transform -rotate-45 animate-[spin_25s_linear_infinite_reverse]" />
        <div className="absolute inset-0 border-2 border-purple-500/5 rounded-full transform rotate-90 animate-[spin_30s_linear_infinite]" />
      </div>

      {/* Spline Animation */}
      <div className="absolute inset-0 z-0">
        <spline-viewer url="https://prod.spline.design/VPz2MBnrDSvZNDMX/scene.splinecode"></spline-viewer>
      </div>

      <div className="relative z-10 text-center max-w-5xl mx-auto mb-8 md:mb-16 bg-black/30 backdrop-blur-sm p-6 md:p-12 rounded-2xl border border-white/10">
        <h1 className="font-light leading-tight mb-6 md:mb-8 drop-shadow-[0_0_25px_rgba(0,0,0,0.5)]">
          Unlock <span className="text-purple-400 font-medium">20×–100×</span> Crypto Returns
          <span className="block mt-4 text-white/90 text-shadow-lg">Risk Managed, Research Driven</span>
        </h1>
        
        <p className="text-[16px] md:text-[20px] text-white/80 max-w-3xl mx-auto mb-8 md:mb-12 drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]">
          Join our exclusive community of successful crypto traders and unlock unprecedented gains with our research-driven, risk-managed approach.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 md:gap-6">
          <a 
            href="#apply" 
            className="w-full sm:w-auto group flex items-center justify-center gap-2 bg-purple-500 hover:bg-purple-600 text-white px-6 md:px-8 py-3 md:py-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_30px_rgba(147,51,234,0.3)]"
          >
            I Want 20×–100× Gains
            <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </a>
          
          <a 
            href="#how" 
            className="w-full sm:w-auto text-center text-white hover:text-purple-400 transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-full after:h-px after:bg-purple-400 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-300"
          >
            See How It Works
          </a>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;