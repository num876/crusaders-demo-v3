import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-32 px-12 border-t border-white/10">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex flex-col items-center gap-16">
          <nav className="flex gap-16">
            <a href="#about" className="nav-link text-[20px]">About Us</a>
            <a href="#docs" className="nav-link text-[20px]">Documentation</a>
            <a href="#privacy" className="nav-link text-[20px]">Privacy</a>
            <a href="#terms" className="nav-link text-[20px]">Terms</a>
          </nav>
          
          <p className="text-[16px] tracking-[4px] uppercase text-white/40">
            © 2025 Crypto Crusaders • Built with Bolt.new
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;