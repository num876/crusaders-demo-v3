import React from 'react';
import { ClipboardCheck, LineChart, BarChart } from 'lucide-react';

const steps = [
  {
    icon: <ClipboardCheck className="h-12 w-12" />,
    title: "Apply & Onboard",
    description: "Complete our 2-minute application form. We assess fit, then invite qualified traders.",
    number: "01"
  },
  {
    icon: <LineChart className="h-12 w-12" />,
    title: "Receive Your Plan",
    description: "Get clear \"buy\" and \"sell\" signals in chat, plus in-depth reports for planning.",
    number: "02"
  },
  {
    icon: <BarChart className="h-12 w-12" />,
    title: "Execute & Grow",
    description: "Follow our guidance, track performance, and watch your portfolio scale.",
    number: "03"
  }
];

const HowItWorks: React.FC = () => {
  return (
    <section id="how" className="min-h-screen flex items-center justify-center px-12">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-center mb-32">How It Works</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-24">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="feature-card relative overflow-hidden"
            >
              <div className="absolute top-8 right-8 text-[64px] font-light opacity-20">
                {step.number}
              </div>
              
              <div className="relative z-10">
                <div className="mb-12 opacity-80">
                  {step.icon}
                </div>
                
                <h3 className="text-[32px] uppercase tracking-[4px] mb-8">
                  {step.title}
                </h3>
                
                <p className="text-[24px] text-white/60 tracking-wider leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;