import React from 'react';

const ChatWidget: React.FC = () => {
  return null;
};

export default ChatWidget;