import React, { useState } from 'react';
import { User, Mail } from 'lucide-react';

const ApplicationForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    investmentLevel: '',
    experience: '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  return (
    <section id="apply" className="min-h-screen flex items-center justify-center px-12">
      <div className="max-w-[800px] w-full mx-auto">
        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="feature-card">
            <h2 className="text-center mb-24">Join the Elite</h2>
            
            <div className="space-y-16">
              <div>
                <label htmlFor="name" className="block text-[20px] uppercase tracking-[4px] mb-4">
                  Full Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-8 flex items-center pointer-events-none opacity-60">
                    <User className="h-6 w-6" />
                  </div>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="form-input"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="email" className="block text-[20px] uppercase tracking-[4px] mb-4">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-8 flex items-center pointer-events-none opacity-60">
                    <Mail className="h-6 w-6" />
                  </div>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-input"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="investmentLevel" className="block text-[20px] uppercase tracking-[4px] mb-4">
                  Investment Level
                </label>
                <select
                  id="investmentLevel"
                  name="investmentLevel"
                  value={formData.investmentLevel}
                  onChange={handleChange}
                  className="form-input"
                  required
                >
                  <option value="">Select your investment level</option>
                  <option value="under5k">Under $5,000</option>
                  <option value="5kTo25k">$5,000 - $25,000</option>
                  <option value="25kTo100k">$25,000 - $100,000</option>
                  <option value="over100k">Over $100,000</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="experience" className="block text-[20px] uppercase tracking-[4px] mb-4">
                  Trading Experience
                </label>
                <select
                  id="experience"
                  name="experience"
                  value={formData.experience}
                  onChange={handleChange}
                  className="form-input"
                  required
                >
                  <option value="">Select your experience level</option>
                  <option value="beginner">Beginner (0-1 years)</option>
                  <option value="intermediate">Intermediate (1-3 years)</option>
                  <option value="advanced">Advanced (3+ years)</option>
                </select>
              </div>
            </div>
            
            <div className="mt-24">
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full flex items-center justify-center gap-4 text-[24px]"
              >
                {isSubmitting ? (
                  <>
                    <div className="h-6 w-6 border-2 border-t-transparent border-white rounded-full animate-spin" />
                    Processing
                  </>
                ) : (
                  'Submit Application'
                )}
              </button>
            </div>
          </form>
        ) : (
          <div className="feature-card text-center">
            <div className="mb-12">
              <div className="w-24 h-24 border-2 border-purple-500/50 rounded-full mx-auto flex items-center justify-center">
                <svg className="w-12 h-12 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <h3 className="text-[32px] uppercase tracking-[4px] mb-8">Application Received</h3>
            <p className="text-[24px] text-white/60 tracking-wider">
              We'll review your application and reach out within 24 hours.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default ApplicationForm;