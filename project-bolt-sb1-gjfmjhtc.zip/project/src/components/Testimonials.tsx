import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const testimonialPhotos = [
  '/src/components/assets/testimonial photos/IMG_9448.jpeg',
  '/src/components/assets/testimonial photos/IMG_9449.jpeg',
  '/src/components/assets/testimonial photos/IMG_9451.jpeg',
  '/src/components/assets/testimonial photos/IMG_9452.jpeg',
  '/src/components/assets/testimonial photos/GoXiHQcXIAAjqm1 (2).jfif',
  '/src/components/assets/testimonial photos/GplEOeWWsAAgi15 (1).jfif',
  '/src/components/assets/testimonial photos/Gra7Mm6WIAAoEda.jfif',
  '/src/components/assets/testimonial photos/Gra7MnAXEAAo2l7.jfif'
];

const Testimonials: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonialPhotos.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const goToPrevious = () => {
    setActiveIndex((prev) => (prev - 1 + testimonialPhotos.length) % testimonialPhotos.length);
  };

  const goToNext = () => {
    setActiveIndex((prev) => (prev + 1) % testimonialPhotos.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (touchStart - touchEnd > 75) {
      // Swipe left
      goToNext();
    }
    if (touchStart - touchEnd < -75) {
      // Swipe right
      goToPrevious();
    }
  };

  return (
    <section id="success" className="py-16 md:py-24 px-4 md:px-8">
      <div className="w-full max-w-[1400px] mx-auto">
        <h2 className="text-center mb-8 md:mb-16">
          Real Results from Real Members
        </h2>
        
        <div className="feature-card relative overflow-hidden p-4 md:p-8">
          {/* Carousel Container */}
          <div 
            className="relative aspect-[4/3] md:aspect-[16/9] mb-6 md:mb-12"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-xl overflow-hidden">
              {testimonialPhotos.map((photo, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-opacity duration-500 ${
                    index === activeIndex ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  <img
                    src={photo}
                    alt={`Member Success Story ${index + 1}`}
                    className="w-full h-full object-contain"
                    loading="lazy"
                  />
                </div>
              ))}
            </div>
            
            {/* Navigation Buttons - Hidden on Mobile */}
            <div className="hidden md:block">
              <button
                onClick={goToPrevious}
                className="absolute left-4 top-1/2 -translate-y-1/2 btn-outline !p-3 md:!p-6 z-10 bg-black/30 backdrop-blur-sm hover:bg-black/50"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="h-6 w-6 md:h-12 md:w-12" />
              </button>
              
              <button
                onClick={goToNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 btn-outline !p-3 md:!p-6 z-10 bg-black/30 backdrop-blur-sm hover:bg-black/50"
                aria-label="Next testimonial"
              >
                <ChevronRight className="h-6 w-6 md:h-12 md:w-12" />
              </button>
            </div>
          </div>
          
          {/* Dots Navigation */}
          <div className="flex justify-center gap-2 md:gap-4 mt-6 md:mt-12">
            {testimonialPhotos.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-2.5 h-2.5 md:w-4 md:h-4 rounded-full transition-all duration-300 ${
                  index === activeIndex
                    ? 'bg-purple-500 scale-125'
                    : 'bg-white/20 hover:bg-white/40'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;