import React from 'react';
import { BookOpen, LineChart, Clock, BadgeCheck } from 'lucide-react';

const features = [
  {
    icon: <BookOpen className="h-12 w-12" />,
    title: "Zero Experience Needed",
    description: "Even if you've never traded before, our step-by-step guidance does the heavy lifting.",
  },
  {
    icon: <LineChart className="h-12 w-12" />,
    title: "Institutional-Grade Research",
    description: "Access the exact coin-selection playbooks and macro-market forecasts our analysts use.",
  },
  {
    icon: <Clock className="h-12 w-12" />,
    title: "Hands-Off Execution",
    description: "Spend 5 minutes a day reviewing our signals—no chart-watching marathon required.",
  },
  {
    icon: <BadgeCheck className="h-12 w-12" />,
    title: "100% Money-Back Guarantee",
    description: "If you aren't profitable after 90 days, we'll refund your entry fee—no questions asked.",
  },
];

const WhyItWorks: React.FC = () => {
  return (
    <section id="why" className="py-64 px-12">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-center mb-32">Why It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-24">
          {features.map((feature, index) => (
            <div key={index} className="feature-card">
              <div className="mb-12 opacity-80">
                {feature.icon}
              </div>
              <h3 className="text-[32px] font-light tracking-[4px] mb-8 uppercase">
                {feature.title}
              </h3>
              <p className="text-white/60 tracking-wider text-[24px] leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyItWorks;