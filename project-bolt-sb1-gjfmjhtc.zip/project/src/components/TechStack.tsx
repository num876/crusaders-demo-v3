import React from 'react';
import { CheckCircle } from 'lucide-react';

const techFeatures = [
  "Expert Technical Analysis Team",
  "Comprehensive Research Sheets",
  "Real-time Market Analysis",
  "Macro Market Forecasting",
  "Risk Management Systems",
  "Portfolio Optimization Tools",
  "Sentiment Analysis Integration",
  "Custom Trading Algorithms"
];

const TechStack: React.FC = () => {
  return (
    <section className="py-64 px-12">
      <div className="max-w-[1400px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-24">
          <div className="space-y-8">
            {techFeatures.map((feature, index) => (
              <div key={index} className="flex items-center gap-6">
                <CheckCircle className="h-8 w-8 text-purple-400 flex-shrink-0" />
                <span className="text-[24px] tracking-wider text-white/80">{feature}</span>
              </div>
            ))}
          </div>
          
          <div className="relative">
            <div className="w-full aspect-square relative">
              {/* Abstract 3D cube animation */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-64 h-64 animate-[spin_20s_linear_infinite]">
                  <div className="absolute inset-0 border-2 border-purple-500/20 rounded-lg transform rotate-45" />
                  <div className="absolute inset-0 border-2 border-purple-500/10 rounded-lg transform -rotate-45 animate-[spin_25s_linear_infinite_reverse]" />
                  <div className="absolute inset-0 border-2 border-purple-500/5 rounded-lg transform rotate-90 animate-[spin_30s_linear_infinite]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechStack;