import React from 'react';
import { Rocket, Globe, Smartphone, GraduationCap } from 'lucide-react';

const goals = [
  {
    icon: <Rocket className="h-12 w-12" />,
    title: "Branding & Expansion",
    description: "Global reach through strategic partnerships and enhanced brand presence."
  },
  {
    icon: <Globe className="h-12 w-12" />,
    title: "New Market Integrations",
    description: "Expanding to emerging markets and new trading platforms."
  },
  {
    icon: <Smartphone className="h-12 w-12" />,
    title: "Mobile App Launch",
    description: "Real-time alerts and portfolio tracking in your pocket."
  },
  {
    icon: <GraduationCap className="h-12 w-12" />,
    title: "Sustainability & Education",
    description: "Comprehensive learning resources for long-term success."
  }
];

const Roadmap: React.FC = () => {
  return (
    <section id="roadmap" className="min-h-screen flex items-center justify-center px-12">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-center mb-32">Key Steps & Future Goals</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-24">
          {goals.map((goal, index) => (
            <div 
              key={index}
              className="feature-card relative overflow-hidden group border-t-2 border-t-purple-500/30"
            >
              <div className="mb-12 opacity-80">
                {goal.icon}
              </div>
              
              <h3 className="text-[32px] uppercase tracking-[4px] mb-8">
                {goal.title}
              </h3>
              
              <p className="text-[24px] text-white/60 tracking-wider leading-relaxed">
                {goal.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Roadmap;