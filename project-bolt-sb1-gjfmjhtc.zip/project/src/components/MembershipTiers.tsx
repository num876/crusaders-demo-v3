import React from 'react';
import { Award, Radio, Compass } from 'lucide-react';

const MembershipTiers: React.FC = () => {
  return (
    <section id="membership" className="min-h-screen flex items-center justify-center px-12">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-center mb-32">Choose Your Path</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Elite Tier */}
          <div className="feature-card relative overflow-hidden group h-full flex flex-col">
            <div className="absolute top-0 right-0 bg-purple-500/20 text-white px-8 py-2 uppercase tracking-[4px]">
              Flagship
            </div>
            
            <div className="flex items-center gap-6 mb-16">
              <Award className="h-16 w-16 opacity-80" />
              <h3 className="text-[32px] uppercase tracking-[4px]">CC Elite</h3>
            </div>
            
            <ul className="space-y-12 mb-16 flex-grow">
              <li>
                <h4 className="text-[20px] font-medium mb-4">Monthly Deep-Dive Reports & Macro Briefings</h4>
                <p className="text-[18px] text-white/60">In-depth analysis of market trends and the "why" behind every coin pick.</p>
              </li>
              
              <li>
                <h4 className="text-[20px] font-medium mb-4">Community Group Chats</h4>
                <p className="text-[18px] text-white/60">Dedicated channels for Health & Fitness, Mindset, Market News, and more—connect with fellow members beyond trading.</p>
              </li>
              
              <li>
                <h4 className="text-[20px] font-medium mb-4">Long-Term Playbook Access</h4>
                <p className="text-[18px] text-white/60">Get our strongest, high-conviction trades straight from the industry's top technical analysts—designed for multi-month, multi-parabolic gains.</p>
              </li>
            </ul>
            
            <a 
              href="#apply" 
              className="btn-primary w-full text-center bg-purple-500 hover:bg-purple-600"
            >
              Apply for Elite
            </a>
          </div>
          
          {/* Signals Tier */}
          <div className="feature-card relative overflow-hidden group h-full flex flex-col">
            <div className="absolute top-0 right-0 bg-white/10 text-white px-8 py-2 uppercase tracking-[4px]">
              Essential
            </div>
            
            <div className="flex items-center gap-6 mb-16">
              <Radio className="h-16 w-16 opacity-80" />
              <h3 className="text-[32px] uppercase tracking-[4px]">CC Signals</h3>
            </div>
            
            <ul className="space-y-12 mb-16 flex-grow">
              <li>
                <h4 className="text-[20px] font-medium mb-4">Short-Term Trade Alerts</h4>
                <p className="text-[18px] text-white/60">Clear "Buy" and "Sell" instructions with recommended entry prices, take-profit targets, and stop-loss levels—so you know exactly when to execute.</p>
              </li>
              
              <li>
                <h4 className="text-[20px] font-medium mb-4">Trade Rationale</h4>
                <p className="text-[18px] text-white/60">For every signal, you'll get a concise explanation of why we're entering that coin—covering trend analysis, on-chain metrics, and market catalysts.</p>
              </li>
              
              <li>
                <h4 className="text-[20px] font-medium mb-4">Signal Updates from CC Elite</h4>
                <p className="text-[18px] text-white/60">Receive real-time updates when CC Elite analysts adjust targets or risk levels, ensuring you stay in sync with our flagship research.</p>
              </li>
            </ul>
            
            <a 
              href="#apply" 
              className="btn-primary w-full text-center bg-purple-500 hover:bg-purple-600"
            >
              Apply for Signals
            </a>
          </div>

          {/* Compass Tier */}
          <div className="feature-card relative overflow-hidden group h-full flex flex-col">
            <div className="absolute top-0 right-0 bg-white/10 text-white px-8 py-2 uppercase tracking-[4px]">
              Research
            </div>
            
            <div className="flex items-center gap-6 mb-16">
              <Compass className="h-16 w-16 opacity-80" />
              <h3 className="text-[32px] uppercase tracking-[4px]">CC Compass</h3>
            </div>
            
            <ul className="space-y-12 mb-16 flex-grow">
              <li>
                <h4 className="text-[20px] font-medium mb-4">Weekly Market Snapshot</h4>
                <p className="text-[18px] text-white/60">A short, jargon-free update breaking down big crypto trends—what moved, why it matters, and what to watch next.</p>
              </li>
              
              <li>
                <h4 className="text-[20px] font-medium mb-4">Light Trade Signals</h4>
                <p className="text-[18px] text-white/60">Essential buy and sell alerts to keep your portfolio on track with market movements.</p>
              </li>
              
              <li>
                <h4 className="text-[20px] font-medium mb-4">13 Altcoin Deep Dives</h4>
                <p className="text-[18px] text-white/60">Detailed analysis of our top altcoin picks, including growth potential, risks, and key metrics to watch.</p>
              </li>
            </ul>
            
            <a 
              href="#apply" 
              className="btn-primary w-full text-center bg-purple-500 hover:bg-purple-600"
            >
              Apply for Compass
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MembershipTiers;