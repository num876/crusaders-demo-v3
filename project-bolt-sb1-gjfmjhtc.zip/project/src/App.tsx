import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import Introduction from './components/Introduction';
import Features from './components/Features';
import WhyItWorks from './components/WhyItWorks';
import MembershipTiers from './components/MembershipTiers';
import Testimonials from './components/Testimonials';
import HowItWorks from './components/HowItWorks';
import ApplicationForm from './components/ApplicationForm';
import Footer from './components/Footer';
import ChatWidget from './components/ChatWidget';

function App() {
  return (
    <div className="min-h-screen text-white font-sans relative">
      {/* Background orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="orb orb-1"></div>
        <div className="orb orb-2"></div>
        <div className="orb orb-3"></div>
      </div>
      
      <Header />
      <main>
        <HeroSection />
        <Introduction />
        <Features />
        <WhyItWorks />
        <MembershipTiers />
        <div className="section-divider">MEMBER SUCCESS STORIES</div>
        <Testimonials />
        <div className="section-divider">START YOUR JOURNEY</div>
        <HowItWorks />
        <ApplicationForm />
      </main>
      <Footer />
      <ChatWidget />
    </div>
  );
}

export default App;