/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Space Grotesk', 'system-ui', 'sans-serif'],
      },
      colors: {
        primary: '#6D28D9', // Purple
        secondary: '#4C1D95', // Darker Purple
        accent: '#7C3AED', // Bright Purple
        dark: {
          DEFAULT: '#0A0A0A',
          100: '#121212',
          200: '#1A1A1A',
          300: '#262626',
        }
      },
      boxShadow: {
        'glow': '0 0 20px rgba(109, 40, 217, 0.2)',
        'glow-lg': '0 0 30px rgba(109, 40, 217, 0.3)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-20px)' },
        }
      }
    },
  },
  plugins: [],
};